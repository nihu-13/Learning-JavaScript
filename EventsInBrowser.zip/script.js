//Browser Events -> An event is a signal that something has happened. All the DOM nodes generate such signals. 
// 1) Mouse Events --> mouseover/mouseout
let d=document.getElementById("d1")
d.onmouseover=(e)=>{
  d.innerHTML="Mouse Over"
}
d.onmouseout=(e)=>{
  d.innerHTML="Mouse Out"
}
// 2) Keyboard Events --> keydown/keyup
let d2=document.getElementById("d2")
d2.onkeydown=(e)=>{
  d2.innerHTML="Key Down"
}
d2.onkeyup=(e)=>{
  d2.innerHTML="Key Up"
}
// 3) Form Events --> submit,focus etc.
let d3=document.getElementById("d3")
d3.onsubmit=(e)=>{
  d3.innerHTML="Form Submitted"
}
d3.onfocus=(e)=>{
  d3.innerHTML="Focused"
}
// 4) Document Events --> DOMContentLoaded
document.onload=(e)=>{
  d3.innerHTML="DOM Loaded"
}
// 5) Window Events --> resize,scroll etc.
window.onresize=(e)=>{
  d3.innerHTML="Window Resized"
}
window.onscroll=(e)=>{
  d3.innerHTML="Window Scrolled"
}

//AddEventListner -> it is used to assign multiple handlers to an event.
let d4=document.getElementById("d4")
d4.addEventListener("click",(e)=>{
  d4.innerHTML="Clicked"
})
//AddEventListner pros -> 
// 1) Event object is passed as an argument when the event is called.
// 2) Event object has a property called target which is the element that triggered the event.
// 3) Event object has a property called type which is the type of the event.
// 4) Event object has a property called currentTarget which is the element that the event is currently triggered on.
// 5) Event object has a property called clientX which is the horizontal coordinate of the cursor when the event was triggered.

//Show different alert when diiferent button are clicked

let a1=documnet.getElementById("b1")
let a2=documnet.getElementById("b2")
let a3=documnet.getElementById("b3")
a1.addEventListner("click",(e)=>{
  alert("Button 1 Clicked")
})
a2.addEventListner("click",(e)=>{
  alert("Button 2 Clicked")
})
a3.addEventListner("click",(e)=>{
  alert("Button 3 Clicked")
})
